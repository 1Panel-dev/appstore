#!/bin/sh




DOCKER_SCAN_SUGGEST=false BUILDKIT_PROGRESS=plain docker-compose up --build developing