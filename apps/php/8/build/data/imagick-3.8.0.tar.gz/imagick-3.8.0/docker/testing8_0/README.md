The testing8_0 box is available.

You can now run `docker exec -it imagick_testing8_0_1 bash` to create a bash session in the container, and then run code inside it.

If you checkout the Imagick project to a project named different from 'imagick' that box name might be different. It can be found by running `docker ps`.