#!/bin/bash

source /.env

$EXEC_SCRIPT
