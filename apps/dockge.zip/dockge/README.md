# Dockge

DockgeDockge是一款简化、易于使用的自托管容器编排工具。

## 主要特性：

- 通过Web页面管理compose.yaml文件。
- 创建/编辑/启动/停止/重新启动/删除容器。
- 更新Docker镜像。
- 交互式Web终端。
- 响应式设计，实时更新进度（Pull/Up/Down）和终端输出。
- 提供了简化的用户体验，可以在一个页面上方便地找到您需要的一切，一目了然。
- 将docker run … 命令转换为compose.yaml配置。
- 基于文件结构，支持使用正常的 Docker Compose 命令进行交互。