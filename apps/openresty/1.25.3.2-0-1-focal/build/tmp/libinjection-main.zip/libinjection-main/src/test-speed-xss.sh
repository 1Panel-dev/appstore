#!/bin/sh
set -e
${VALGRIND} ./testspeedxss
